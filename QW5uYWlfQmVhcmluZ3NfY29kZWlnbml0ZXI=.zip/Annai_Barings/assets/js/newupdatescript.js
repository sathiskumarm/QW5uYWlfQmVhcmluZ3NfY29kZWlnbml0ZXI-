$(document).ready(function () { 
	$('html').hide().fadeIn(2500).delay(6000);
	// $('.item').hide();
});

// $(function() {
//   	$('#hideandshow').change(function(){
//     	$('.item').hide();
//     	$('#' + $(this).val()).show();
//   	});
// });

